README for the Database of Catalan Adjectives.
==============================================
Created gbt 30/09/2009
Modified gbt 04/11/2009
Modified gbt 20/12/2010 (minor aspects of the README)
Modified gbt 20/09/2022 (minor aspects of the README)

LICENSE. These data are licensed under a Creative Commons Attribution Share Alike 3.0 Spain license. That means that you can use the data for whatever purposes (including commercial purposes) as long as you cite the source of the data and any derived product is licensed with the same type of license.

CITATION. If you mention results obtained using the Database of Catalan Adjectives, you should cite the following article:

Roser Sanromà and Gemma Boleda. 2010. The Database of Catalan Adjectives. In Proceedings of the Seventh International Conference on Language Resources and Evaluation (LREC'10), Valletta, Malta. European Language Resources Association (ELRA).

FORMAT. The database is in UTF-8, csv (comma-separated value) format. You can visualize it with any spreadsheet software (e.g., OpenOffice or Excel).

CONTENT. The database contains 2,296 alphabetically ordered adjective lemmata (rows) and 45 columns with various types of linguistic information about each lemma. The adjectives correspond to those occurring more than 50 times in a 14.5 million word fragment of the Corpus Informatitzat de la Llengua Catalana (Rafel 1994), developed at the Institut d'Estudis Catalans. The texts of this fragment were written between 1969 and 1988. The information in the columns has been semi-automatically extracted from the corpus or encoded manually.

The columns code the following information (order as in the database). For further details about columns 2 and 4-24, see Sanromà (2003); for further details about columns 3 and 25-45, see Boleda (2007).

1. id: numerical identifier of the adjective.
2. lemma: lemma of the adjective.
3. lemma2: same as lemma, except for participles, for which the verbal lemma is encoded instead.
4. freq: frequency of the lemma in an 8-million fragment of the corpus. Percentages for the counts in columns 11-25 should be computed on these frequencies.
5. derType: morphological (derivational) type of the adjective: "basic", "denominal_I" (sinchronically denominal adjectives), "denominal_II" (not sinchronically denominal adjectives), "deverbal_I" (sinchronically deverbal adjectives), "deverbal_II" (not sinchronically deverbal adjectives) or "participle".
6. suffix: suffix of denominal and deverbal adjectives (when no suffix applies, the value '-' is stated).
7. NArank: adjective frequency rank in postnominal position (with optional adverbs between the noun and the adjective). Correspondences between frequency percentage and rank values are the following: from 0% to 1% rank value is 6, from 1% to 5% is 5, from 5% to 25% is 4, from 25% to 50% is 3, from 50% to 75% is 2 and from 75% to 100% is 1.
8. VArank: adjective frequency rank in postverbal position (with optional adverbs between the verb and the adjective). Correspondences between rank values and frequency percentage are like those for NArank.
9. ANrank: adjective frequency rank in prenominal position. Correspondences between rank values and frequency percentage are like those for NArank.
10. group: syntactic group of the adjective established from NArank, VArank and Anrank. Adjectives with similar rank values pertain to a same group.
11. NA: frequency of the adjective immediately after a noun.
12. NAdvA: frequency of the adjective after a noun whith at least one adverb between them.
13. VA: frequency of the adjective immediately after a verb.
14. VAdvA: frequency of the adjective after a verb whith at least one adverb between them.
15. AN: frequency of the adjective immediately before a noun.
16. ArtA: frequency of the adjective immediately after an article.
17. ArtAdvA: frequency of the adjective after an article whith at least one adverb between them.
18. PrepA: frequency of the adjective immediately after a preposition
19. PrepAdvA: frequency of the adjective after a preposition whith at least one adverb between them.
20. SPunctA: frequency of the adjective immediately after a punctuation mark.
21. SPunctAdvA: frequency of the adjective after a punctuation mark whith at least one adverb between them.
22. IA: frequency of the adjective immediately after conjunctions i ('and') or o ('or').
23. IAdvA: frequency of the adjective after conjunctions  i ('and') or o ('or') with at least one adverb between them.
24. AA: frequency of the adjective immediately preceded by another adjective.
25. AAdvA: frequency of the adjective preceded by another adjective whith at least one adverb between them.
26. freq2: frequency of the adjective in a 14.5 million fragment of the corpus. Values in columns 27-44 are proportions computed over this frequency (to recover the actual counts, simply multiply the value in a column by the corresponding freq2 value), with two exceptions: (1) Values for columnds def, nondef, bare, hSubj, hObj, and hPrepComp were computed as proportions within the total number of occurrences of each adjective as a nominal modifier (not shown in the present version of the database); (2) values for disthead are mean distances to the head noun (that is why the values do not range between 0 and 1 as the remaining columns).
27. pl: occurrences of the adjective in plural.
28. fem: occurrences of the adjective in feminine. Some Catalan adjectives are underspecified with respect to gender. For these cases, we use a default value estimated from the frequencies of all adjectives in the corpus, namely, 0.48 for feminine.
29. nonrestr: occurrences of the adjective as a pre-nominal modifier.
30. atr: occurrences of the adjective as a predicate in a copular sentence.
31. pred: occurrences of the adjective as a predicate in a non-copular sentence.
32. estar: occurrences of the adjective as a predicate in a copular sentence where the copula is 'estar'.
33. predGlob: occurrences of the adjective as a predicate (sum of atr and pred).
34. grad: occurrences of the adjective in a gradable construction (e.g., preceded by a gradable adverb or bearing a suffix such as -íssim).
35. comp: occurrences of the adjective in a comparable construction: tan|més|... ADJ com|que.
36. gradGlob: gradable global -- sum of grad and comp.
37. def: occurrences of the adjective in an NP headed by a definite determiner.
38. nondef: occurrences of the adjective in an NP headed by an indefinite determiner.
39. bare: occurrences of the adjective in an NP headed by no determiner.
40. disthead: in the modifying function, mean distance to the head, in number of words.
41. hSubj: occurrences of the adjective in an NP acting as the subject of a verb.
42. hObj: occurrences of the adjective in an NP acting as the object of a verb.
43. hPrepComp: occurrences of the adjective in an NP acting as a prepositional complement (as in "la cara de la nena *petita*", 'the face of the little girl').
44. binary: occurrences of the adjective immediately followed by a preposition (signals potential complements in Catalan).
45. semantic_class: semantic class of a sample of 210 adjectives from the database. The encoding distinguishes between basic (B), event-related (E), object-related (O), and the complex or polysemous classes basic-event (BE) and event-object (EO).

REFERENCES

Boleda, Gemma. 2007. Automatic acquisition of semantic classes for adjectives. Unpublished Ph.D. thesis, Universitat Pompeu Fabra. Available at the author's homepage.

Sanromà, Roser and Boleda, Gemma. 2010. The Database of Catalan Adjectives. In Proceedings of LREC 2010, Valletta, Malta.

Rafel, Joaquim. 1994. Un corpus general de referència de la llengua catalana. Caplletra, 17:219–250.

Sanromà, Roser. 2003. Aspectes morfològics i sintàctics dels adjectius en català. Unpublished master’s thesis, Universitat Pompeu Fabra.

