#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct  5 18:45:25 2021

@author: gboleda
"""

import pandas as pd
import seaborn as sns
#from sklearn.linear_model import LinearRegression

df = pd.read_csv('survey-life-satisfaction.csv')

df.plot.scatter(x='shoe_size', y='height')
sns.lmplot(x='shoe_size', y='height',data=df,fit_reg=True) 
