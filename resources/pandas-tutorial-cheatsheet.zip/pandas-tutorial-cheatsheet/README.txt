Computational semantics, MLTA, Universitat Pompeu Fabra
------

* Pandas tutorial / cheatsheet * -- license: CC BY-SA 4.0

Note: We provide both pdf and odt versions of the tutorial / cheatsheet such that you can modify it or expand it if you want. 

- Data used in the tutorial / cheatsheet, in case you want to practice: 

	practice-dataframe.csv - simple toy dataset. Entirely made-up. 

	survey-life-satisfaction.csv - survey data gathered within a course taught by G. Boleda. Each row contains data about one person; the columns are self-explanatory, I hope. 


